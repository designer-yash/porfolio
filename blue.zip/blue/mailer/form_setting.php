<?php
	/*Form settings*/
	$subj = "New message from the site 'You Site Name'"; //letter subject
	$to = 'beshleygame@mail.ru'; // Enter Your E-mail
	$from = 'admin@you-site-name.com'; // Admin e-mail
	$fromName = 'Your Company Name'; // Your company name
	$charset = 'UTF-8';
?>